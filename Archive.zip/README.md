# somedaybusiness
 Nettside for someday business


v1: Designet og kodet av Amund Bjørnstad & Jon-Magne Aa. Jønholt

v2: Designet og kodet av Jon-Magne Aa. Jønholt